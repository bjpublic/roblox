-- DisplayOthersLaser 로컬 스크립트
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
-- 레이저 빔 파트를 생성하는 모듈 스크립트를 재사용한다.
local LaserRenderer = require(script.Parent:WaitForChild("LaserRenderer"))

-- 다른 플레이어의 레이저 빔을 렌더링
local function displayOthersLaser(player, startPos, endPos)
    -- 해당 플레이어가 레이저를 발사한 플레이어가 아니라면,
    if player ~= Players.LocalPlayer then
        LaserRenderer.createLaser(startPos, endPos)
    end
end

ReplicatedStorage.FiredLaser.OnClientEvent:Connect(displayOthersLaser)