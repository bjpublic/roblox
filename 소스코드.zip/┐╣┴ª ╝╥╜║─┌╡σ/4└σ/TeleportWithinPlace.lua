-- TeleportWithinPlace
local TeleportWithinPlace = {}

function TeleportWithinPlace.TeleportPlayer(player, pos)
    local character = player.Character
    if character ~= nil and character.Parent ~= nil  then
        local humanoid = character:FindFirstChild("Humanoid")
        if humanoid and not humanoid:GetAttribute("Teleporting") then
            humanoid:SetAttribute("Teleporting", true)
            local character = humanoid.Parent
            -- 주어진 좌표에서 캐릭터의 루트 파트의 높이를 적당히 계산함.
            local rootPartY = (humanoid.RootPart.Size.Y * 0.5) + humanoid.HipHeight
            -- 계산한 루트 파트의 높이만큼 더함
            local position = CFrame.new(pos + Vector3.new(0, rootPartY, 0))
            -- 캐릭터 이동
            character:SetPrimaryPartCFrame(position)

            humanoid:SetAttribute("Teleporting", nil)
        end
    end
end

return TeleportWithinPlace
