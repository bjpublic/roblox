local TweenService = game:GetService("TweenService")
local Players = game:GetService("Players")
local player = Players.LocalPlayer

-- 블러 효과 생성
local blurEffect = Instance.new("BlurEffect")
blurEffect.Parent = workspace.CurrentCamera
-- 색상 보정 효과 생성
local colorCorrectionEffect = Instance.new("ColorCorrectionEffect")
colorCorrectionEffect.Parent = workspace.CurrentCamera

-- 효과에 사용될 상수들
local EFFECT_DURATION = 6 -- 6초간 적용시킴
local TINT_COLOR = Color3.fromRGB(200, 45, 45) -- 변경될 틴트 색상
local BLUR_INTENSITY = 56 -- 블러 효과의 intensity는 56까지

-- "TweenInfo" 오브젝트 설정
local deathEffectInfo = TweenInfo.new(EFFECT_DURATION)

-- TweenService 객체들 생성
local tweenBlur = TweenService:Create(blurEffect, deathEffectInfo, {Size = BLUR_INTENSITY})
local tweenColor = TweenService:Create(colorCorrectionEffect, deathEffectInfo, {TintColor = TINT_COLOR})

-- 캐릭터 소환 시에 실행될 함수
local function setupDeathTween(character)
    --포스트 이펙트 비활성화
    blurEffect.Enabled = false
    colorCorrectionEffect.Enabled = false

    -- 휴머노이드 찾기
    print("hu")
    local humanoid = character:WaitForChild("Humanoid")
    -- 휴머노이드가 죽으면 실행될 함수 연결
    humanoid.Died:Connect(function()
        -- 포스트 이펙트 초기화
        blurEffect.Size = 0
        colorCorrectionEffect.TintColor = Color3.fromRGB(255, 255, 255)
        --포스트 이펙트 활성화
        blurEffect.Enabled = true
        colorCorrectionEffect.Enabled = true
        -- Tween 실행
        tweenBlur:Play()
        tweenColor:Play()
    end)

end

-- 캐릭터가 소환될 때의 이벤트 CharacterAdded
player.CharacterAdded:Connect(setupDeathTween)
