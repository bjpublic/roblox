local Players = game:GetService("Players")
local random = Random.new()

local function onPlayerJoin(player)
    local spawnLocations = workspace.SpawnLocations:GetChildren()
    local rand = random:NextInteger(1, #spawnLocations)
    local randomSL = spawnLocations[rand]
    player.RespawnLocation = randomSL
end

Players.PlayerAdded:Connect(onPlayerJoin)