local Players = game:GetService("Players")
local ServerStorage = game:GetService("ServerStorage")

-- 킬 수를 증가시킬 함수
local function onKillPlayer(playerFired)
    local kills = playerFired.leaderstats.Kills
    -- 킬 수 증가
    kills.Value = kills.Value + 1
end

-- KillEvent 객체의 Event에 함수 연결
ServerStorage.KillEvent.Event:Connect(onKillPlayer)

local function onPlayerAdded(player)
    local leaderstats = Instance.new("Folder")
    leaderstats.Name = "leaderstats"
    leaderstats.Parent = player

    local kills = Instance.new("IntValue")
    -- IntValue의 이름은 Kills
    kills.Name = "Kills"
    -- IntValue의 값은 0
    kills.Value = 0
    -- IntValue 객체는 반드시 leaderstats 폴더의 자식으로 설정
    kills.Parent = leaderstats

    -- 플레이어 객체의 CharacterAdded 이벤트에 연결된 Anonymous함수
    player.CharacterAdded:Connect(function(character)
        -- 캐릭터의 휴머노이드를 찾는다.
        local humanoid = character:WaitForChild("Humanoid")

        -- 멀티 플레이어 테스트를 하면 이름과 모습이 
        -- 똑같은 캐릭터들로 테스트를 해야 하기 때문에 테스트가 어렵다.
        -- 휴머노이드의 DisplayName 속성에 캐릭터 이름을 넣어주면 
        -- 원래는 두 캐릭터 모두 Player라고 나오는데, 
        -- Player1, Player2라고 나와서 그나마 캐릭터끼리 서로 구분이 된다.
        -- humanoid.DisplayName = character.Name

        -- 휴머노이드 객체의 Died 이벤트에 연결된 Anonymous함수
        humanoid.Died:Connect(function()
            -- 리더보드 점수 리셋
            local kills = player.leaderstats.Kills
            kills.Value = 0
        end)
    end)
end

Players.PlayerAdded:Connect(onPlayerAdded)



