local SoundService = game:GetService("SoundService")

-- 반복 재생될 사운드 ID 리스트
local songs = {
    "rbxassetid://1836842889",
    "rbxassetid://1837849285",
    "rbxassetid://7023861220",
}

-- 반복 재생될 사운드 객체의 리스트
local soundObjects = {}
-- 사운드 ID 리스트를 반복문에서 사용함
for _, songID in ipairs(songs) do
    -- 사운드 ID에서 사운드 객체를 생성
    local soundObject = Instance.new("Sound")
    soundObject.SoundId = songID
    soundObject.Volume = 0.2
    soundObject.Parent = SoundService
    -- 사운드 객체 리스트에 사운드 객체를 추가
    table.insert(soundObjects, soundObject)
end

-- 무한 반복
while true do
    -- 사운드 객체 리스트를 반복문에서 사용함
    for currentSongIndex = 1, #soundObjects do
        -- 인덱스로 사운드 객체 얻기
        local currentSongObject = soundObjects[currentSongIndex]
        -- 사운드 플레이
        currentSongObject:Play()
        -- 사운드 플레이 Ended 이벤트가 나올 때까지 기다림.
        currentSongObject.Ended:Wait()
    end
end