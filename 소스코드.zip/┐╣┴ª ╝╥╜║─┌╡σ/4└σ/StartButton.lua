-- StartButton
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

-- 텔레포트 모듈 스크립트 Require
local TeleportWithinPlace = require(ReplicatedStorage.TeleportWithinPlace)

-- 버튼 파트
local teleportPart = script.Parent
-- 버튼 반복 클릭 방지용 플래그
local isStarted = false

local function onCheckStart(otherPart)
    if not isStarted then
        isStarted = true
        
        -- 사람 수를 체크하고 스타트
        local players = Players:GetPlayers()
        if #players >= 2 then
            for _, player in pairs(players) do
                -- 좌표는 레이스가 시작되는 장소
                TeleportWithinPlace.TeleportPlayer(player, Vector3.new(-162, 30, -376))
            end
            -- 순간 이동된 1초 후부터 카운트다운 시작
            wait(1)
            game:GetService("ServerStorage").StartLightEvent:Fire()
        end
    end
end

teleportPart.Touched:Connect(onCheckStart)
-- 레이스가 끝나면 초기화를 시켜서 다시 버튼을 누를 수 있게 함
game:GetService("ServerStorage").FinishEvent.Event:Connect(function()
    isStarted = false
end)

while wait() do
    if isStarted == false and #Players:GetPlayers() >= 2 then
        teleportPart.BrickColor = BrickColor.Red()
    else
        teleportPart.BrickColor = BrickColor.Gray()
    end
end