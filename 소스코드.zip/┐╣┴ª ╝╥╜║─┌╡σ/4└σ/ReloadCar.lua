local ReplicatedStorage = game:GetService("ReplicatedStorage")
local reloadCarEvent = ReplicatedStorage:WaitForChild("ReloadCarEvent")

local button = script.Parent

local colorNormal = Color3.new(1, 1, 1) -- white
local colorPress = Color3.new(0.7, 0.7, 0.7) -- grey

-- 리모트 이벤트만 발생하고 끝. 나머지는 모두 서버에서 처리한다.
local function onButtonActivated()
    reloadCarEvent:FireServer()
end

-- 버튼을 누르면 색을 바꾼다.
local function onPressed()
    button.ImageColor3 = colorPress
end
-- 버튼 클릭 해제하면 색을 원래대로 바꾼다.
local function onReleased()
    button.ImageColor3 = colorNormal
end

button.Activated:Connect(onButtonActivated)
button.MouseButton1Down:Connect(onPressed)
button.MouseButton1Up:Connect(onReleased)
