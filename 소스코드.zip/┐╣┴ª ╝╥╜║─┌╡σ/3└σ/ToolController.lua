-- ToolController 로컬 스크립트
local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local MAX_MOUSE_DISTANCE = 1024
local MAX_LASER_DISTANCE = 512
local FIRE_RATE = 0.5
local timeOfPreviousShot = 0

-- 모듈 스크립트를 require 함수로 불러온다.
local LaserRenderer = require(Players.LocalPlayer.PlayerScripts.LaserRenderer)

local tool = script.Parent

local function get3DMousePos()
    local mouse2D = UserInputService:GetMouseLocation()
    -- 마우스의 2D 위치에서 카메라방향으로 유닛 Ray(광선)을 생성
    local screenToWorldRay = workspace.CurrentCamera:ViewportPointToRay(mouse2D.X, mouse2D.Y)
    -- MAX_DISTANCE 만큼의 길이를 가지는 벡터를 얻음
    local directionVector = screenToWorldRay.Direction * MAX_MOUSE_DISTANCE
    -- workspace의 Raycast 함수를 호출하여 레이캐스팅한 결과를 얻는다
    local raycastResult = workspace:Raycast(screenToWorldRay.Origin, directionVector)
    if raycastResult then
        -- 레이캐스트로 감지한 물체가 있으면 그 위치를 반환한다.
        return raycastResult.Position
    else
        -- 레이캐스트로 감지한 물체가 없으면 최대거리의 위치를 계산하여 반환한다.
        return screenToWorldRay.Origin + directionVector
    end
end

local function fireWeapon()
    local mouseLocation = get3DMousePos()
    -- 총의 위치
    local gunLocation = tool.Handle.Position
    local vv = mouseLocation - tool.Handle.Position
    local targetDirection = vv.Unit * MAX_LASER_DISTANCE

    -- 플레이어 자신이 발사한 레이저에는 레이캐스팅의 대상이 되지 않게 설정
    -- RaycastParams 객체를 생성하는 new함수
    local weaponRaycastParams = RaycastParams.new()
    -- RaycastParams 객체에 Players.LocalPlayer.Character(본인 플레이어 캐릭터 모델)을 설정
    -- RaycastFilterType의 기본값은 Blacklist임
    weaponRaycastParams.FilterDescendantsInstances = {Players.LocalPlayer.Character}
    -- 레이캐스팅
    local weaponRaycastResult = workspace:Raycast(tool.Handle.Position, targetDirection, weaponRaycastParams)
    -- 명중했다면 레이캐스팅의 결과 위치가 hitPosition에 대입된다.
    local hitPosition = weaponRaycastResult.Position
    if weaponRaycastResult then
        -- 상대 플레이어에게 명중되었다면 그 명중된 파트는 캐릭터 모델의 하위 노드 중에 하나 일 것이다.
        -- 그 파트에서 캐릭터 모델을 찾고 그 캐릭터 모델에서 휴머노이드를 찾는다.
        -- 휴머노이드가 있다면 그 파트는 상대 플레이어이고, 없다면 그냥 다른 어떤 물체인 것이다.
        local characterModel = weaponRaycastResult.Instance:FindFirstAncestorOfClass("Model")
        if characterModel then
            local humanoid = characterModel:FindFirstChild("Humanoid")
            if humanoid then
                -- 서버에게 DamagePlayer 리모트 이벤트로 캐릭터 모델을 전달한다.
                ReplicatedStorage.DamagePlayer:FireServer(characterModel, hitPosition)
            end
        end
    else
        -- 명중하지 못했다면 시작 위치와 방향벡터로 계산된 위치가 대입된다.
        hitPosition = tool.Handle.Position + targetDirection
    end
    timeOfPreviousShot = tick()
    LaserRenderer.createLaser(tool.Handle.Position, hitPosition)
    -- 서버에게 FiredLaser 리모트 이벤트로 레이저 빔의 끝 위치를 전달한다.
    ReplicatedStorage.FiredLaser:FireServer(hitPosition)
end

-- 레이저 빔 발사 후에 충분한 시간이 흘렀는지를 체크
local function canShootWeapon()
    local currentTime = tick()
    if currentTime - timeOfPreviousShot < FIRE_RATE then
        return false
    end
    return true
end

local function toolEquipped()
    -- 사운드 객체의 Play 함수를 호출하면 사운드가 출력된다.
    tool.Handle.Equipped:Play()
end

local function toolActivated()
    if canShootWeapon() then
        tool.Handle.Activated:Play()
        fireWeapon()
    end
end

tool.Equipped:Connect(toolEquipped)
tool.Activated:Connect(toolActivated)
