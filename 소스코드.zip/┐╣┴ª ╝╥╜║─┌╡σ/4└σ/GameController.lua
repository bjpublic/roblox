-- GameController
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

-- 텔레포트 모듈 스크립트 Require
local TeleportWithinPlace = require(ReplicatedStorage:WaitForChild("TeleportWithinPlace"))

-- 모든 체크포인트를 리스트로 가지고 옴.
local checkPoints = workspace.CheckPoints:GetChildren()
-- 부정 출발 방지용 시작 파트
local startPart = workspace.StartPart
-- 우승자를 정하는 파트
local finishPart = workspace.FinishPart
-- 레이스 끝났는지를 알리는 플래그(flag)
local isFinished = false

-- 레이스 게임 초기화
local function initialize()
    -- 모든 체크 포인트, 시작 파트, 결승선 파트 투명하게 한다.
    startPart.Transparency = 1
    finishPart.Transparency = 1
    for _, part in ipairs(checkPoints) do
        part.Transparency = 1
    end
end

-- 레이스가 끝나고 게임을 정리
local function clearAll()
    -- 체크 포인트의 플레이어 아이디 표시 제거
    for _, part in ipairs(checkPoints) do
        if part:IsA("StringValue") then
            part:Destroy()
        end
    end
    -- 레이싱 카 제거
    for _, car in ipairs(workspace.Cars:GetChildren()) do
        car:Destroy()
    end
end

-- 우승자를 알려주는 GUI
local function ShowVictoryMessage(winnerPlayer, player)
    --local message = Instance.new("Message")
    --message.Text = winnerPlayer.name .. "님이 이겼습니다!"
    --message.Parent = workspace
    --game:GetService("Debris"):AddItem(message, 3)
    local screenGui = Instance.new("ScreenGui")
    screenGui.IgnoreGuiInset = true
    local frame = Instance.new("Frame")
    frame.Size = UDim2.new(1, 0, 1, 0)
    frame.BackgroundColor3 = Color3.new(0, 0, 0)
    frame.BackgroundTransparency = 0.5
    local tLabel = Instance.new("TextLabel")
    tLabel.Text = winnerPlayer.name .. "님이 이겼습니다!"
    tLabel.TextSize = 50
    tLabel.TextColor3 = Color3.new(255, 255, 255)
    tLabel.Position = UDim2.new(0.5, 0, 0.5, 0)
    tLabel.Parent = frame
    frame.Parent = screenGui
    screenGui.Parent = player.PlayerGui
    game:GetService("Debris"):AddItem(screenGui, 3)
end

-- 레이스 시작 이벤트 발생시 처리 함수
local function onStartRace()
    startPart.CanCollide = false
    isFinished = false
end

-- 체크 포인트 파트를 터치할 때 처리 함수
local function onTouchedCheckPoint(checkPoint, otherPart)
    -- 터치한 파트의 부모 노드가 있는지를 먼저 체크
    if otherPart ~= nil and otherPart.Parent ~= nil then
        -- 부모 노드에 휴머노이드 객체가 있는지 체크
        local humanoid = otherPart.Parent:FindFirstChild("Humanoid")
        if humanoid then
            -- 부모 노드에 휴머노이드 객체가 있다면 그 부모 노드는 캐릭터 모델이다.
            local character = otherPart.Parent
            -- 캐릭터 모델에서 플레이어 객체를 불러옴
            local player = game.Players:GetPlayerFromCharacter(character)
            if player then
                -- 플레이어 UserId로 등록된 객체가 이미 존재하지 않다면,
                if not checkPoint:FindFirstChild(player.UserId)  then
                    -- 플레이어 UserId로 객체를 만들어서 체크 포인트 파트에 자식 노드로 추가한다.
                    local playerTag = Instance.new("StringValue")
                    playerTag.Parent = checkPoint
                    playerTag.Name = player.UserId
                end
            end
        end
    end
end

-- 결승선 파트를 터치할 때 처리 함수
local function onTouchedFinish(otherPart)
    if otherPart ~= nil and otherPart.Parent ~= nil then
        local humanoid = otherPart.Parent:FindFirstChild("Humanoid")
        if humanoid then
            local character = otherPart.Parent
            local winnerPlayer = game.Players:GetPlayerFromCharacter(character)
            if winnerPlayer then
                local checkWinner = true
                -- 이 플레이어가 모든 체크 포인트에 터치했는지 확인
                for _, cp in ipairs(checkPoints) do
                    if not cp:FindFirstChild(winnerPlayer.UserId) then
                        checkWinner = false
                        break
                    end
                end
                if checkWinner and not isFinished then
                    isFinished = true
                    -- Game Over
                    for _, player in pairs(Players:GetPlayers()) do
                        ShowVictoryMessage(winnerPlayer, player)
                    end
                    wait(2.8)
                    clearAll()
                    wait(0.2)
                    -- 로비로 텔레포트
                    for _, player in pairs(Players:GetPlayers()) do
                        TeleportWithinPlace.TeleportPlayer(player, workspace.Lobby.SpawnLocation.Position)
                    end
                    wait(1)
                    game:GetService("ServerStorage").FinishEvent:Fire()
                end
            end
        end
    end
end


-- 레이스 게임 준비
local function prepareGame()
    startPart.CanCollide = true
    local serverStorage = game:GetService("ServerStorage")
    local car1 = serverStorage.Car1:Clone()
    car1.Parent = workspace.Cars
    local car2 = serverStorage.Car2:Clone()
    car2.Parent = workspace.Cars
    local car3 = serverStorage.Car3:Clone()
    car3.Parent = workspace.Cars
    local car4 = serverStorage.Car4:Clone()
    car4.Parent = workspace.Cars
end

-- 레이스 신호 이벤트와 함수 연결
ServerStorage.StartLightEvent.Event:Connect(function()
    prepareGame()
end)
-- 레이스 시작 이벤트와 함수 연결
ServerStorage.StartEvent.Event:Connect(onStartRace)
-- 모든 체크 포인트에 터치 이벤트와 함수를 연결
for _, part in ipairs(checkPoints) do
    part.Touched:Connect(function(otherPart)
        onTouchedCheckPoint(part, otherPart)
    end)
end
-- 결승선 파트에 터치 이벤트 함수 연결
finishPart.Touched:Connect(onTouchedFinish)

local function onReloadCar(player)
    -- 플레이어가 타고 있는 차 찾기
    local reloadCar = nil
    for _, car in pairs(workspace.Cars:GetChildren()) do
        local seat = car.PrimaryPart
        local owner = seat:GetNetworkOwner()
        if owner == player  then
            reloadCar = car
            break
        end
    end
    
    if reloadCar then
        reloadCar:Destroy()
        local clonedCar = ServerStorage[reloadCar.Name]:Clone()
        -- 시작 지점이 아니라 가까운 체크 포인트로 옮기는 것 추천.
        -- CFrame pos = CFrame.new(원하는 위치)
        -- clonedCar:SetPrimaryPartCFrame(pos)
        clonedCar.Parent = workspace.Cars
        wait(2)
        -- 캐릭터도 같이 이동
        -- 차 모델이 제거되는데 시간이 걸리기 때문에 잠시 기다리고 이동
        TeleportWithinPlace.TeleportPlayer(player, Vector3.new(-162, 30, -376))
    end
end

ReplicatedStorage.ReloadCarEvent.OnServerEvent:Connect(onReloadCar)

-- 레이스 게임의 초기화
initialize()
