-- CarController
local car = script.Parent
local vehicleSeat = car.BasePart.VehicleSeat

local motorFR = car.WheelUnitFR:FindFirstChildWhichIsA("CylindricalConstraint", true)
local motorFL = car.WheelUnitFL:FindFirstChildWhichIsA("CylindricalConstraint", true)
local motorBR = car.WheelUnitBR:FindFirstChildWhichIsA("CylindricalConstraint", true)
local motorBL = car.WheelUnitBL:FindFirstChildWhichIsA("CylindricalConstraint", true)

local wheelHingeR = car.WheelUnitFR:FindFirstChildWhichIsA("HingeConstraint", true)
local wheelHingeL = car.WheelUnitFL:FindFirstChildWhichIsA("HingeConstraint", true)

-- 좌, 우회전의 최고 각도
local MAX_TURN_ANGLE = 30

-- 전진을 위한 토크
local TORQUE = 50000 
-- 후진을 위한 토크
local BACK_TORQUE = 50000
-- 브레이크를 위한 토크
local BRAKING_TORQUE = 20000
-- 전진 최고 속도
local MAX_VELOCITY = 160
-- 후진 최고 속도
local MAX_BACK_VELOCITY = -40

-- 토크 바꾸기
local function setMotorTorque(torque)
    motorFR.MotorMaxTorque = torque
    motorFL.MotorMaxTorque = torque
    motorBR.MotorMaxTorque = torque
    motorBL.MotorMaxTorque = torque
end

-- 최고 속도 정하기
local function setMotorVelocity(vel)
    motorFL.AngularVelocity = vel
    motorBL.AngularVelocity = vel
    -- 오른쪽 바퀴들은 왼쪽 바퀴에서 180도 회전되었기 때문에 반대 속도로로 정해줘야 한다.
    motorFR.AngularVelocity = -vel
    motorBR.AngularVelocity = -vel
end

while true do
    -- 키 입력
    local steer = vehicleSeat.Steer
    local throttle = vehicleSeat.Throttle
    -- 원하는 각도 계산
    local turnAngle = steer * MAX_TURN_ANGLE
    -- 힌지 제약 객체의 TargetAngle에 입력
    wheelHingeR.TargetAngle = turnAngle
    wheelHingeL.TargetAngle = turnAngle
        
    local targetVelocity = 0
    local motorTorque = 0
    
    -- 정지
    if throttle == 0 then
        targetVelocity = 0
        motorTorque = BRAKING_TORQUE
    -- 전진
    elseif throttle > 0 then
        targetVelocity = MAX_VELOCITY
        motorTorque = TORQUE
    -- 후진
    else
        targetVelocity = MAX_BACK_VELOCITY
        motorTorque = BACK_TORQUE
    end
    setMotorTorque(motorTorque)
    setMotorVelocity(targetVelocity)
    
    wait()
end