local Lighting = game:GetService("Lighting")

-- 9AM 부터 시작
local minutesAfterMidnight = 9 * 60 
while true do
    -- 10분씩 시간을 증가시킨다.
    minutesAfterMidnight = minutesAfterMidnight + 10
    Lighting:SetMinutesAfterMidnight(minutesAfterMidnight)
    wait(20)
end
