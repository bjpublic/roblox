-- GamePass
local MarketplaceService = game:GetService("MarketplaceService")

local gamePassID = 0000000

-- 구매 완료 이벤트와 연결된 함수
local function onPromptGamePassPurchaseFinished(player, purchasedPassID, purchaseSuccess)
    if purchaseSuccess == true and purchasedPassID == gamePassID then
        print(player.Name .. " 님이 게임 패스: " .. gamePassID .. "를 구매했습니다.")
        -- 여기서 부터 게임 패스의 효과가 나오게끔 게임 패스의 내용을 구현한다.
    end
end

-- PromptGamePassPurchaseFinished 이벤트와 함수를 연결
MarketplaceService.PromptGamePassPurchaseFinished:Connect(onPromptGamePassPurchaseFinished)
