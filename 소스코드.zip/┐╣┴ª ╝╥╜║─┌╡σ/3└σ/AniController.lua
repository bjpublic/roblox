local Players = game:GetService("Players")
local tool = script.Parent

-- test R15 인지 R6인지 확인
--wait(5)
--local Players = game:GetService("Players")
--local player = Players.LocalPlayer
--local humanoid = Players.LocalPlayer.Character.Humanoid
--print(humanoid.RigType)

local MAX_MOUSE_DISTANCE = 1024
local MAX_LASER_DISTANCE = 512
local FIRE_RATE = 0.5
local timeOfPreviousShot = 0

local player = Players.LocalPlayer
local character = player.Character
if not character or not character.Parent then
    character = player.CharacterAdded:Wait()
end
local humanoid = character:WaitForChild("Humanoid")
local animator = humanoid:WaitForChild("Animator")

local aimAnimation = Instance.new("Animation")
-- 애니메이션 ID는 앞에서 만든 커스텀 애니메이션의 ID
aimAnimation.AnimationId = "rbxassetid://7431325793"
-- 애니메이션 트랙 로드
local aniTrack = animator:LoadAnimation(aimAnimation)
aniTrack.Priority = Enum.AnimationPriority.Action
aniTrack.Looped = true

local function toolEquipped()
    -- 애니메이션 실행
    aniTrack:Play()
end

local function toolUnequipped()
    -- 애니메이션 중지
    aniTrack:Stop()
end

tool.Equipped:Connect(toolEquipped)
tool.Unequipped:Connect(toolUnequipped)