-- AttackManager 서버 스크립트
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local LASER_DAMAGE = 30

-- 피격 위치 허용 범위
local MAX_HIT_PROXIMITY = 9


local MAX_LASER_DISTANCE = 512
local function isLayCastingValid(playerFired, characterToDamage, hitPosition)
    local weapon = playerFired.Character:FindFirstChildOfClass("Tool")
    -- 도구가 있는 플레이어만이 레이저 빔을 발사할 수 있다.
    if weapon then
        -- 도구가 없거나 도구 안에 Handle이 없는 상태라면 handle은 nil을 가질 것이다.
        local toolHandle = weapon:FindFirstChild("Handle")
        -- 총구 위치와 피격 위치 간의 레이캐스팅
        if toolHandle then
            local rayDirection = (hitPosition - toolHandle.Position).Unit * MAX_LASER_DISTANCE
            local raycastParams = RaycastParams.new()
            raycastParams.FilterDescendantsInstances = {playerFired.Character}
            local rayResult = workspace:Raycast(toolHandle.Position, rayDirection, raycastParams)
            if rayResult then
                -- 캐릭터의 하위 노드가 아니면 검증 성공
                if rayResult and rayResult.Instance:IsDescendantOf(characterToDamage) then
                    return true
                end
            end
        end
    end
    return false 
end

local function isHitValid(playerFired, characterToDamage, hitPosition)
    local humanoid = characterToDamage:FindFirstChild("Humanoid")
    if humanoid then
        -- 캐릭터 위치와 피격 위치의 거리 계산
        local characterHitProximity = (humanoid.RootPart.Position - hitPosition).Magnitude
        if characterHitProximity > MAX_HIT_PROXIMITY then
            -- 유효성 검증 실패
            return false
        end
    end
    if isLayCastingValid(playerFired, characterToDamage, hitPosition) == false then
        return false
    end
    -- 여기까지 오면 유효성 검증 성공!
    return true
end

function damagePlayer(playerFired, characterToDamage, hitPosition)
    local humanoid = characterToDamage:FindFirstChild("Humanoid")
    local isValid = isHitValid(playerFired, characterToDamage, hitPosition)
    if humanoid and isValid then
        -- 받은 캐릭터 모델에서 휴머노이드를 찾아서 Health를 줄인다.
        humanoid.Health -= LASER_DAMAGE
        
        -- 플레이어가 죽으면
        if humanoid.Health <= 0 then
            -- KillEvent 발생
            -- ServerStorage.KillEvent:Fire(playerFired)
            ReplicatedStorage.KillPlayer:FireClient(playerFired)

        end
    else
        print("검증 실패")
    end
end

local function notifyFiredLaser(playerFired, endPos)
    local weapon = playerFired.Character:FindFirstChildOfClass("Tool")
    -- 도구가 있는 플레이어만이 레이저 빔을 발사할 수 있다.
    if weapon then
        -- 도구가 없거나 도구 안에 Handle이 없는 상태라면 handle은 nil을 가질 것이다.
        local handle = weapon:FindFirstChild("Handle")
        if weapon then
            -- 레이저 빔의 시작 위치
            local startPos = handle.Position
            -- 모든 클라이언트에게 레이저 빔 발사 정보를 전달한다.
            ReplicatedStorage.FiredLaser:FireAllClients(playerFired, startPos, endPos)
        end
    end
end

-- 함수와 이벤트를 연결
ReplicatedStorage.DamagePlayer.OnServerEvent:Connect(damagePlayer)
ReplicatedStorage.FiredLaser.OnServerEvent:Connect(notifyFiredLaser)
