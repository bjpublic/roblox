local MAX_HEALTH = 100
local ENABLED_TRANSPARENCY = 0      -- 사용되기 전에 힐 아이템은 불투명하다. 
local DISABLED_TRANSPARENCY = 1     -- 사용된 후의 힐 아이템은 투명해진다.
local COOLDOWN = 20                 -- 사용된 후에 20초가 지나면 다시 나타난다.

local healsFolder = workspace:WaitForChild("Heals")
local heals = healsFolder:GetChildren()

local function onTouchHeal(otherPart, item)
    -- 아이템이 사용가능 상태인지 확인
    if item:GetAttribute("Enabled") then 
        local character = otherPart.Parent
        local humanoid = character:FindFirstChildWhichIsA("Humanoid")
        if humanoid then
            humanoid.Health = MAX_HEALTH
            -- 사용후에는 아이템을 투명하게 하고 사용 불가 상태로 변경
            item.Transparency = DISABLED_TRANSPARENCY
            item:SetAttribute("Enabled", false)
            -- 쿨타임
            wait(COOLDOWN)
            -- 쿨타임 후, 다시 아이템이 사용 가능 상태로 변경
            item.Transparency = ENABLED_TRANSPARENCY
            item:SetAttribute("Enabled", true)
        end
    end
end

for _, item in ipairs(heals) do
    -- 모든 힐 아이템에게 "Enabled"라는 Attribute를 추가하고 true로 셋팅
    item:SetAttribute("Enabled", true)
    item.Touched:Connect(function(otherPart)
        onTouchHeal(otherPart, item)
    end)
end