local DAMAGE_PER_HIT = 5
local trap = script.Parent

local function onTouchHealthPickup(otherPart, trap)
    local character = otherPart.Parent
    local humanoid = character:FindFirstChildWhichIsA("Humanoid")
    if humanoid then
        humanoid.Health = humanoid.Health - DAMAGE_PER_HIT
    end
end

trap.Touched:Connect(function(otherPart)
    onTouchHealthPickup(otherPart, trap)
end)