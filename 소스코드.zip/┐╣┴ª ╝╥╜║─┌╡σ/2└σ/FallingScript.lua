
local part=script.Parent
local isTouched=false
local originPosition=part.Position
--배열 정의
local stepTable={0.05, 0.06, 0.09, 0.09, 0.12, 0.12, 0.2, 0.2, 0.3, 0.3}
local function fall()
    if not isTouched then
        isTouched=true
        for count=1, 100 do
            --count를 사용하여 stepTable에서 사용될 키를 계산함
            local key=math.floor(((count-1)/10)+1)
            --step은 stepTable에 정의된 데이터를 매칭시켜 사용함
            local step=stepTable[key]
            --step만큼씩 아래로 이동시킴
            part.Position=part.Position+Vector3.new(0, -1*step, 0)
            wait()
        end
        isTouched=false
        part.Position=originPosition
    end
end
part.Touched:Connect(fall)