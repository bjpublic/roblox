-- GamePassLocal
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")

local gamePassID = 00000000

local button = script.Parent

-- Function to prompt purchase of the game pass
local function promptPurchase()

    local player = Players.LocalPlayer
    local hasPass = false

    local success, message = pcall(function()
        -- 게임 패스를 가지고 있는지 확인
        hasPass = MarketplaceService:UserOwnsGamePassAsync(player.UserId, gamePassID)
    end)

    if not success then
        warn("Error while checking if player has pass: " .. tostring(message))
        return
    end

    if hasPass then
        -- 플레이어가 이미 게임 패스를 가지고 있음
    else
        -- 게임 패스를 가지고 있지 않으므로 게임 패스 구매 창을 띄움.
        MarketplaceService:PromptGamePassPurchase(player, gamePassID)
    end
end

button.Activated:Connect(promptPurchase)