-- StartLightScript
local lightModel = script.Parent
-- 신호 라이트 레퍼런스
local redLight = lightModel.Red
local yellowLight = lightModel.Yellow
local greenLight = lightModel.Green
-- 신호 사운드 레퍼런스
local oneSound = script.One
local twoSound = script.Two
local threeSound = script.Three
local BEEP = script.BEEP
-- 시작 이벤트가 발생하면 실행하는 함수
function onStart()
    -- 쓰리
    threeSound:Play()
    redLight.Transparency = 0
    wait(1)
    -- 투
    twoSound:Play()
    yellowLight.Transparency = 0
    wait(1)
    -- 원
    oneSound:Play()
    greenLight.Transparency = 0
    wait(1)
    
    -- 레이스 시작
    game:GetService("ServerStorage").StartEvent:Fire()
    BEEP:Play()
end

-- StartEvent가 발생하면 실행되는 함수를 연결
game:GetService("ServerStorage").StartLightEvent.Event:Connect(onStart)
game:GetService("ServerStorage").FinishEvent.Event:Connect(function()
    redLight.Transparency = 1
    yellowLight.Transparency = 1
    greenLight.Transparency = 1
end)

