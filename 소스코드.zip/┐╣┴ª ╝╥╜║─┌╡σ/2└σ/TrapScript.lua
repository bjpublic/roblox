local trap = script.Parent

local function kill(otherPart)
    local characterModel = otherPart.Parent
    local humanoid = characterModel:FindFirstChild("Humanoid")
    -- 휴머노이드가 nil인지를 체크
    if humanoid ~= nil then
        humanoid.Health = 0
    end
end

-- Connect함수로 Touched 이벤트와 kill함수를 연결
trap.Touched:Connect(kill)