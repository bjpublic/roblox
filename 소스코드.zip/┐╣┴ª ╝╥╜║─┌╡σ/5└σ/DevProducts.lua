local MarketplaceService = game:GetService("MarketplaceService")
local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")
 
local purchaseHistoryStore = DataStoreService:GetDataStore("PurchaseHistory")
 
-- 개발자 제품 아이디를 키로, 처리 함수를 값으로 갖는 테이블
local productFunctions = {}
productFunctions[10683302] = function(receipt, player)
    -- 개발자 제품 10683302 은 비트 코인 1개를 얻는다.
	local stats = player:FindFirstChild("leaderstats")
	local bitcoin = stats and stats:FindFirstChild("BitCoin")
    if bitcoin then
        bitcoin.Value = bitcoin.Value + 1
		return true
	end
end
 
-- ProcessReceipt 콜백 함수의 샘플
local function processReceipt(receiptInfo)
    -- 플레이어 아이디, 구매 아이디를 조합으로 키를 생성해서 이미 데이터스토어에 저장된 것인지 확인.
	local playerProductKey = receiptInfo.PlayerId .. "_" .. receiptInfo.PurchaseId
	local purchased = false
	local success, errorMessage = pcall(function()
		purchased = purchaseHistoryStore:GetAsync(playerProductKey)
	end)
    -- 데이터스토어에 저장된 결과를 확인.
    -- 이미 저장되어 있다면 승인된 구매이기 때문에 더 이상 진행하지 않음.
	if success and purchased then
		return Enum.ProductPurchaseDecision.PurchaseGranted
	elseif not success then
		error("데이터 스토어 에러:" .. errorMessage)
	end
 
	local player = Players:GetPlayerByUserId(receiptInfo.PlayerId)
	if not player then
        -- 플레이어 객체가 없다는 것은 이미 게임에서 빠져 나갔다는 것.
        -- 다시 게임에 참가했을때 처리할 수 있게 체크해 둠.
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	
    -- 개발자 제품 아이디와 처리 함수의 쌍으로 이루어진 테이블에서
    -- 개발자 제품 아이디로 처리 함수를 얻어옴.
	local handler = productFunctions[receiptInfo.ProductId]
 
	-- 안전 모드로 처리 함수 실행
	local success, result = pcall(handler, receiptInfo, player)
	if not success or not result then
		warn("제품 구매 과정 중 에러 발생!")
		print("제품 아이디:", receiptInfo.ProductId)
		print("플레이어:", player)
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
    
    -- 구매 트랜젝션을 데이터스토어에 저장.
	local success, errorMessage = pcall(function()
		purchaseHistoryStore:SetAsync(playerProductKey, true)
	end)
	if not success then
		error("Cannot save purchase data: " .. errorMessage)
	end
 
	return Enum.ProductPurchaseDecision.PurchaseGranted
end
 
-- ProcessReceipt 콜백 설정. 
-- 한 서버 스크립트에서만 실행해야 함.
MarketplaceService.ProcessReceipt = processReceipt
