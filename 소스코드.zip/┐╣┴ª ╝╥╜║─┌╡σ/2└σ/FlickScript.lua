local part = script.Parent
local function flicker()
    wait(3)
    part.Transparency = 0.7
    wait(1)
    part.Transparency = 1
    part.CanCollide = false
    wait(3)
    part.Transparency = 0
    part.CanCollide = true
end
while true do
    flicker()
end