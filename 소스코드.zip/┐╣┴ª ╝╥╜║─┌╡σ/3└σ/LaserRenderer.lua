-- LaserRenderer 모듈 스크립트
local LaserRenderer = {}

-- 레이저가 보여지는 시간
local SHOT_DURATION = 0.15 

-- 시작 위치와 끝 위치를 매개변수로 받으면 레이저를 렌더링 한다.
function LaserRenderer.createLaser(startPos, endPos)
    -- Part 객체를 생성한다.
    local laserPart = Instance.new("Part")
    laserPart.Anchored = true
    laserPart.CanCollide = false
    laserPart.Color = Color3.fromRGB(225, 0, 0)
    laserPart.Material = Enum.Material.Neon
    -- 레이저 빔의 실제 길이를 계산한다.
    local laserDistance = (startPos - endPos).Magnitude
    -- 레이저 빔의 길이로 사이즈를 변경한다. x축, y축은 레이저 빔의 두께를 뜻하고, z축이 길이가 된다.
    laserPart.Size = Vector3.new(0.2, 0.2, laserDistance)
    -- 레이저 파트의 위치와 회전을 정한다.
    local laserCFrameTemp = CFrame.lookAt(startPos, endPos)
    laserPart.CFrame = laserCFrameTemp * CFrame.new(0, 0, -laserDistance * 0.5)
    -- 모든 객체는 workspace의 하위 노드로 있어야 렌더링 된다.
    laserPart.Parent = workspace

    -- Debris 서비스에게 일정시간 후 제거하도록 함
    game.Debris:AddItem(laserPart, SHOT_DURATION)
end

return LaserRenderer