-- DevProductsLocal

-- GetDeveloperProductsAsync 함수는 Pages 객체로 반환한다.
local developerProducts = game:GetService("MarketplaceService"):GetDeveloperProductsAsync():GetCurrentPage()

for _, developerProduct in pairs(developerProducts) do
    for field, value in pairs(developerProduct) do
        print(field .. ": " .. value)
    end
    print("------------------------")
end

local MarketplaceService = game:GetService("MarketplaceService")
local productID = 10685093
-- 개발자 제품의 상세 정보 얻음.
local productInfo = MarketplaceService:GetProductInfo(productID, Enum.InfoType.Product)
print("productInfo:", productInfo)
