--게임 패스는 마켓 플레이스 서비스를 사용한다.
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
--자신이 추가한 게임 패스 아이디
local gamePassID = 0000000
--플레이어가 게임에 참가하면 실행되는 함수
local function onPlayerAdded(player)
    local hasPass = false
    --플레이어가 해당 게임 패스 아이디를 가지는지 확인
    local success, message = pcall(function()
        hasPass = MarketplaceService:UserOwnsGamePassAsync(player.UserId, gamePassID)
    end)
    if not success then
        warn("Error while checking if player has pass:" .. tostring(message))
        return
    end
    if hasPass == true then
        print(player.Name .. "님은 게임 패스:" .. gamePassID .. "를 가집니다.")
        --여기서부터 게임 패스와 관련된 특별 능력/추가 콘텐츠들을 연결하는 소스 코드를 넣는다.
    end
end
--"PlayerAdded" 이벤트와 onPlayerAdded 함수를 연결
Players.PlayerAdded:Connect(onPlayerAdded)